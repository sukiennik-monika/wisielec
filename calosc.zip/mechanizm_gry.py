# -*- coding: windows-1250 -*-
import random

# s�ownik z modelami szubienicy
szubienica = {

    0: """
    _ _ _ _ _
    |       |
    |
    |
    |
    |
    |
    |_ _ _ _ _ _ """,

    1: """
    _ _ _ _ _
    |       |
    |       O
    |
    |
    |
    |
    |_ _ _ _ _ _ """,

    2: """
    _ _ _ _ _
    |       |
    |       O
    |       |
    |
    |
    |
    |_ _ _ _ _ _ """,

    3: """
    _ _ _ _ _
    |       |
    |       O
    |     / |
    |
    |
    |
    |_ _ _ _ _ _ """,

    4: """
    _ _ _ _
    |       |
    |       O
    |     / | \\
    |
    |
    |
    |_ _ _ _ _ _ """,

    5: """
    _ _ _ _
    |       |
    |       O
    |     / | \\
    |       |
    |
    |
    |_ _ _ _ _ _ """,

    6: """
    _ _ _ _
    |       |
    |       O
    |     / | \\
    |       |
    |      |
    |
    |_ _ _ _ _ _ """,

    7: """
    _ _ _ _
    |       |
    |       O
    |     / | \\
    |       |
    |      | |
    |
    |_ _ _ _ _ _ """,

    8: """
    _ _ _ _
    |       |
    |       O
    |     / | \\
    |       |
    |      | |
    |      |
    |_ _ _ _ _ _ """,

    9: """
    _ _ _ _
    |       |
    |       O
    |     / | \\
    |       |
    |      | |
    |      | |
    |_ _ _ _ _ _ """

}


# funkcja, kt�ra sprawdza, czy litera jest w s�owie
def check_word(f_guess, f_word, f_fail_count, f_correct, f_incorrect, f_play, f_clue_index_list):

    # jesli gracz odgadn�� zadane s�owo:
    if f_guess == f_word:
        print(f_word.upper())                       # DODA� UPPER
        print("Gratulacje - prze�y�e�!")
        f_play = False                      # KONIEC GRY

    # je�li gracz wprowadzi� jedn� liter�:
    elif len(f_guess) == 1:

        # je�li ju� wcze�niej pr�bowa� odgadn�� t� liter�:
        if f_guess in f_correct or f_guess in f_incorrect:
            print("Ta litera ju� by�a u�ywana, spr�buj innaczej")

        # litera zosta�a wprowadzona po raz pierwszy
        else:
            # zgadywana litera jest w s�owie
            if f_guess in f_word:
                f_correct.append(f_guess)
                f_clue_index_list.append(f_word.index(f_guess))
                # sprawdzenie czy odgadni�ta litera sprawia, �e odgadni�te zosta�o ca�e s�owo
                # w zbiorach kolejno�� nie ma znaczenia oraz elementy si� nie powtarzaj�, st�d rzutowanie
                if set(f_word) == set(f_correct):
                    print(f_word)
                    print("Gratulacje - prze�y�e�!")
                    f_play = False
                else:
                    print("Dobrze, co raz mniej do zgadywania!")
                    #je�li Ci si� uda to zrobi�bym rozr�nienie  komunikatu,
                    #tj dla odgadni�tej jest ten komunikat, ale je�li kto� u�y� gwiazdki, to dostaje komunikat w stylu:
                    #'Oto twoja podpowied�" czy co�. Chodzi mi o to, �eby po u�yciu gwiazdki gracz nie dostawa�
                    #'pochwa�y'. Ale jak co� to jest ma�a rzecz wi�c jak tak zostanie to te� git
                    for letter in f_word:
                        if letter in f_correct:
                            print(letter, end = " ")
                        else:
                            print("_ ", end = " ")
                    print(" ")
                    print(szubienica[f_fail_count])
            # zgadywanej litery nie ma w s�owie
            else:
                f_incorrect.append(f_guess)
                f_fail_count += 1
                print("Tej litery nie ma w Twoim s�owie!")
                print(szubienica[f_fail_count])

    # gracz wprowadzi� kilka liter, ale nie s� one zadanym s�owem
    else:
        # je�li ju� pr�bowa� odgadn�� tak� kombinacj�
        if f_guess in f_correct or f_guess in f_incorrect:
            print("Ju� pr�bowa�e� odgadn�� to s�owo, spr�buj inaczej")
        else:
            f_incorrect.append(f_guess)
            f_fail_count += 1
            print("To nie to s�owo!")
            print(szubienica[f_fail_count])

    # wypisanie liter, kt�re by�y ju� poprzednio zgadywane:
    if f_play:
        print("\nTu pojawiaj� si� podane przez Ciebie b��dne litery i s�owa: ", ", ".join(f_incorrect))
    print("-" * 100)

    return f_fail_count, f_correct, f_incorrect, f_play


def game(word_="���", stars=3):
    star_count = stars
    #(dostosowa� do poziom�w trudno�ci odpowiedni� ilo��, po z��czeniu plik�w- pewnie jako argument funkcji- ale to p�niej)
    word = word_
    correct = []
    incorrect = []
    clue_index_list = []
    play = True
    fail_count = 0
    # guess_count = 0        EW. DO STATYSTYK
    print("S�owo, kt�re musisz odgadn��:")
    for underscore in word:
        print("_ ", end=" ")
    print(" ")

    while (play is True) and (fail_count < 9):

        # FUNKCJONALNO�� - GWIAZDKA = PODPOWIED�
        clue = False
        if star_count > 0:
            print("Pozosta�e podpowiedzi: " + ("* " * star_count))
            answer = input("Czy chcesz skorzysta� z podpowiedzi? (*/n): ")
            #zamieni�bym na: je�li chcesz skorzysta� z gwiazdki, wprowad� (np) znak
            # kropki- tak �eby nie musie� za ka�dym razem dawa� n, kiedy sie nie chce
            if answer == "*":
                # losowanie indeksu litery w s�owie:
                while not clue:
                    clue_index = random.randint(0, len(word) - 1)
                    if clue_index not in clue_index_list:
                        clue_index_list.append(clue_index)
                        check_word(word[clue_index], word, fail_count, correct, incorrect, play, clue_index_list)  # funkcja czy w s�owie
                        star_count -= 1
                        play = result[3]
                        clue = True
            elif answer == "n":
                clue = False
            else:
                print("Podaj '*' lub 'n'.")
                print("-" * 30)
                clue = True
        else:
            print("Sko�czy�y Ci si� podpowiedzi!")
            #WA�NE je�li rozegrasz gr� tak, �eby w momencie wygranej sko�czy�y Ci si� wszystkie gwaizdki, tj twoja ostatnia
            #litera zostaje ods�oni�ta dzi�ki gwiazdce to gra si� nie ko�czy- wy�wietla si� komunikat o braku gwiazdek i gra
            #trwa dalej pomimo tego �e has�o ju� zosta�o zgadni�te. Muszisz pokombinowa� z tymi elif, else if itd.

        # CI�G DALSZY
        if clue is False:
            guess = input("Zgadnij liter� lub s�owo: ").lower()
            result = check_word(guess, word, fail_count, correct, incorrect, play, clue_index_list)
            play = result[3]
            fail_count = result[0]
            correct = result[1]             #nie musi w sumie tego by�
            incorrect = result[2]           #nie musi w sumie tego by�

    if fail_count == 9:
        print("Przegra�e�!")
        print("Twoim has�em by�o: ", word)
    else:
        print("Uda�o Ci si�!")

    return 0