# -*- coding: windows-1250 -*-
import os
import wczytanie_hasel
import mechanizm_gry
import wczytanie_gry
import statystyka as sts


clear = lambda: os.system('cls')  #IDLE nie czysci, terminal tak, do ustalnia co robimy// metoda z len(str)

def main():
    print("Wprowad� swoj� nazw�- dzi�ki niej, b�dziesz m�g� p�niej wczyta� gr� lub zobaczy� swoje wyniki")
    player = str(input()) #narazie gracze to "Player X"- za x wstaw 1-8
    number=" "
    while (number != "0"):
        print("\n\n-------------------------MENU G��WNE-------------------------")
        print(" 1- Nowa gra\n","2- Wczytaj gr�\n","3- Statystki\n","4- Zasady gry\n","0- Wyjd�")
        number=str(input())
        if number == "1":       #nowa gra
            word_star=wczytanie_hasel.load_word() #funkcja zwraca krotk� (slowo,ilosc gwiazdek)
            word= word_star[0]
            star= word_star[1]
            mechanizm_gry.game(word, star)        #przekazuje wylosowane slowo i ilosc gwaizdek- TU ODBYWA SI� GRA

        elif number == "2":     #wczytaj gre
            profil = wczytanie_gry.wybor_profilu()
            wczytanie_gry.game_save(profil[0],profil[1],profil[2],profil[3], profil[4])

        elif number == "3":      #statystki
            print("1- Zasady punktacji\n2- Ranking punkt�w\n3- Szczeg�owe statystyki\n4- Twoje statystyki\n"
                  "POWR�T DO G��WNEGO MENU- dowolny inny znak")
            choice = int(input())
            if choice == 1:
                print("Punkty s� przyznawane wed�ug nast�puj�cego schematu:\n"
                      "+5pkt za ka�d� odgadni�t� liter�\n"
                      "+25pkt za odgadni�cie has�a\n"
                      "+20pkt wygranie gry bez u�ycia �adnej gwaizdki (podpowiedzi)\n\n"
                      "Dodatkowo obowi�zuj� mno�niki, dopasowane do poziom�w trudno�ci:\n"
                      "�atwy- x1\n�redni- x1.5\nTrudny- x2")

            elif choice == 2:
                sts.pts_rank()
            elif choice == 3:
                sts.adv_stats()
            elif choice == 4:
                sts.your_stats(player)
            else:
                break
        elif number == "4":
            print("\nZASADY GRY: \n",
"1. Wymy�l� s�owo z wybranej przez Ciebie kategorii i na ekranie wy�wietl� tyle kresek,\n\tz ilu liter si� ono sk�ada. Twoim zadaniem jest je odgadn�� literka po literce.\n"\
,"2. Je�li trafisz - litera pojawi si� w odpowiednim miejscu zamiast kreski. Je�li trafisz tak�, \n\tkt�ra w s�owie wyst�puje w kilku miejscach - w jednym kroku pojawi si� ona na ka�dym z nich. \n\tWygrywasz, kiedy uda Ci si� odgadn�� ca�e s�owo.\n"\
,"3. Musisz jednak uwa�a� - w rogu, z ka�d� nieudan� pr�b� odgadni�cia litery,\n\tpojawia si� kolejna cz�� rysunku szubienicy. Je�li przekroczysz dozwolon� liczb� pr�b - zawi�niesz!\n\tNie dopu�� do tego.")
            clear()
        elif number != "0":
            print("Nieprawid�owy znak")

if __name__=='__main__' : main()